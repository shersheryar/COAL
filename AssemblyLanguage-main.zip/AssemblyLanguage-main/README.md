# AssemblyLanguage :  [Assembly Playlist Youtube](https://youtube.com/playlist?list=PLmeQIS8S5cYPt37d-ZkdCKrbU5Yu7rpG1)
# Lab 12:  Introduction to Display Memory and practical example with Assembly code|Assembly Coding,  
## [Lab 12 Live recording](https://youtu.be/33zbHcMG2Ss)
## How to Take input (string and character) in NASM, how to Print(string character ) in NASM
## What is Display memory
## How to access Display Memory
## How write a string on Display Memory
## How to clear Display Memory
## How to draw some thing on display memory
## How to Print(string, character and number  ) in NASM
## How to Take input (string, character and number) in NASM

# Lab 13: Interrupts
## [Lab 13 Live recording](https://youtu.be/bYxFvCm9iak)
## How to clear screen using scrool up and scrool down 
## How to write character and string on screen 
## How to make drawing on screen 
## Lab 13: Interupts and function 
## Lab 13: Drawing on screen. 
## Lab 13: ClearScreenUsingScrollUp.asm
## Lab 13: ClearScreenUsingScrolldown.asm
## Lab 13: DrawRectangleinAssembly.asm
## Lab 13: PrintAStringInAssembly.asm
## Lab 13: PrintaCharacterInAssembly.asm
## Lab 13: SetBorderColorsInAssembly.asm
## Lab 13: SetCursorPositionInAssembly.asm
## Lab 13: SetModeInAssembly.asm
## Lab 13: WriteAStringInRectangleInAssembly.asm

# Lab 14: Link Assembly code with C Language| Write 64/32 bit Assembly code and run it
## [Lab 14 Live recording](https://youtu.be/Q9nmOeLvP_c)
## -Guide: How to install NASM and GCC compiler.
## -How to compile and link Assembly object file with C code.
## -Call Assembly code from C Language.
## -Pass parameters from C Language to Assembly Language
## -Return parameters from Assembly Langhuage to C.
## -Write and run 32bit and 64bit Assembly code


